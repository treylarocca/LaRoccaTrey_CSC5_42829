/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 *
 * Created on March 9, 2016, 8:08 AM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set variable data types
    float n; //Number we are trying to get the square root of
    float guess; //The guess at what the square root may be
    float r; //The residual
    float lbe; //Loop body executions
   
    //Get value for n
    cout<<"Please enter the number you would like the square root of."<<endl;
    cin>>n;
    
    //Set lbe to 100 loops
    lbe=100;
    
    //Calculate first approximation
    guess=n/2;
    r=n/guess;
    guess=(guess+r)/2;
    
    //Output first approximation
    cout<<"First Approximation: square root("<<n<<") = r("<<r<<"), guess("
            <<guess<<")."<<endl;
    
    //Calculate Second Approximation
    r=n/guess;
    guess=(guess+r)/2;
    
    //Output second approximation
    cout<<"Second Approximation: square root("<<n<<") = r("<<r<<"), guess("
            <<guess<<")."<<endl;
    
    //Calculate Third Approximation
    r=n/guess;
    guess=(guess+r)/2;
    
    //Output third approximation
    cout<<"Third Approximation: square root("<<n<<") = r("<<r<<"), guess("
            <<guess<<")."<<endl;
    
    //Calculate fourth Approximation
    r=n/guess;
    guess=(guess+r)/2;
    
    //Output fourth approximation
    cout<<"Fourth Approximation: square root("<<n<<") = r("<<r<<"), guess("
            <<guess<<")."<<endl;
    
    //Calculate fifth Approximation
    r=n/guess;
    guess=(guess+r)/2;
    
    //Output fifth approximation
    cout<<"Fifth Approximation: square root("<<n<<") = r("<<r<<"), guess("
            <<guess<<")."<<endl;
    
    //Calculate sixth Approximation
    r=n/guess;
    guess=(guess+r)/2;
    
    //Output sixth approximation
    cout<<"Sixth Approximation: square root("<<n<<") = r("<<r<<"), guess("
            <<guess<<")."<<endl;
    
    
    return 0;
}

