/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program replicates the "Truth Table" illustrated by Dr. Lehr on the
 * white board. 
 * Created on March 14, 2016, 9:38 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {

    //Program purpose prompt
    cout<<"This program replicates the \"Truth Table\" illustrated by Dr. Lehr "
            "on the white board."<<endl;
    cout<<" "<<endl;
    
    //Declare variables for Row 1
    bool x=true;
    bool y=true;
    bool notx=!x;
    bool noty=!y;
    bool xAndy=x&&y;
    bool xOry=x||y;
    bool xXy=x^y;
    bool xXyXy=x^y^y;
    bool xXyXx=x^y^x;
    bool notxny=!(x&&y);
    bool nxorny=(!x)||(!y);
    bool notxory=!(x||y);
    bool nxandny=(!x)&&(!y);
    
    //Output values for Row 1
    cout<<"| "<<(x?'T':'F')<<" | ";
    cout<<(y?'T':'F')<<" | ";
    cout<<(notx?'T':'F')<<" | ";
    cout<<(noty?'T':'F')<<" | ";
    cout<<(xAndy?'T':'F')<<" | "; 
    cout<<(xOry?'T':'F')<<" | ";
    cout<<(xXy?'T':'F')<<" | ";
    cout<<(xXyXy?'T':'F')<<" | ";
    cout<<(xXyXx?'T':'F')<<" | ";
    cout<<(notxny?'T':'F')<<" | ";
    cout<<(nxorny?'T':'F')<<" | ";
    cout<<(notxory?'T':'F')<<" | ";
    cout<<(nxandny?'T':'F')<<" |"<<endl;
    
    //Declare variables for Row 2
    x=true;
    y=false;
    notx=!x;
    noty=!y;
    xAndy=x&&y;
    xOry=x||y;
    xXy=x^y;
    xXyXy=x^y^y;
    xXyXx=x^y^x;
    notxny=!(x&&y);
    nxorny=(!x)||(!y);
    notxory=!(x||y);
    nxandny=(!x)&&(!y);
    
    //Output values for Row 2
    cout<<"| "<<(x?'T':'F')<<" | ";
    cout<<(y?'T':'F')<<" | ";
    cout<<(notx?'T':'F')<<" | ";
    cout<<(noty?'T':'F')<<" | ";
    cout<<(xAndy?'T':'F')<<" | "; 
    cout<<(xOry?'T':'F')<<" | ";
    cout<<(xXy?'T':'F')<<" | ";
    cout<<(xXyXy?'T':'F')<<" | ";
    cout<<(xXyXx?'T':'F')<<" | ";
    cout<<(notxny?'T':'F')<<" | ";
    cout<<(nxorny?'T':'F')<<" | ";
    cout<<(notxory?'T':'F')<<" | ";
    cout<<(nxandny?'T':'F')<<" |"<<endl;
    
    //Declare variables for Row 3
    x=false;
    y=true;
    notx=!x;
    noty=!y;
    xAndy=x&&y;
    xOry=x||y;
    xXy=x^y;
    xXyXy=x^y^y;
    xXyXx=x^y^x;
    notxny=!(x&&y);
    nxorny=(!x)||(!y);
    notxory=!(x||y);
    nxandny=(!x)&&(!y);
    
    //Output values for Row 3
    cout<<"| "<<(x?'T':'F')<<" | ";
    cout<<(y?'T':'F')<<" | ";
    cout<<(notx?'T':'F')<<" | ";
    cout<<(noty?'T':'F')<<" | ";
    cout<<(xAndy?'T':'F')<<" | "; 
    cout<<(xOry?'T':'F')<<" | ";
    cout<<(xXy?'T':'F')<<" | ";
    cout<<(xXyXy?'T':'F')<<" | ";
    cout<<(xXyXx?'T':'F')<<" | ";
    cout<<(notxny?'T':'F')<<" | ";
    cout<<(nxorny?'T':'F')<<" | ";
    cout<<(notxory?'T':'F')<<" | ";
    cout<<(nxandny?'T':'F')<<" |"<<endl;
    
    //Declare variables for Row 4
    x=false;
    y=false;
    notx=!x;
    noty=!y;
    xAndy=x&&y;
    xOry=x||y;
    xXy=x^y;
    xXyXy=x^y^y;
    xXyXx=x^y^x;
    notxny=!(x&&y);
    nxorny=(!x)||(!y);
    notxory=!(x||y);
    nxandny=(!x)&&(!y);
    
    //Output values for Row 4
    cout<<"| "<<(x?'T':'F')<<" | ";
    cout<<(y?'T':'F')<<" | ";
    cout<<(notx?'T':'F')<<" | ";
    cout<<(noty?'T':'F')<<" | ";
    cout<<(xAndy?'T':'F')<<" | "; 
    cout<<(xOry?'T':'F')<<" | ";
    cout<<(xXy?'T':'F')<<" | ";
    cout<<(xXyXy?'T':'F')<<" | ";
    cout<<(xXyXx?'T':'F')<<" | ";
    cout<<(notxny?'T':'F')<<" | ";
    cout<<(nxorny?'T':'F')<<" | ";
    cout<<(notxory?'T':'F')<<" | ";
    cout<<(nxandny?'T':'F')<<" |"<<endl;
    
    
    return 0;
}

