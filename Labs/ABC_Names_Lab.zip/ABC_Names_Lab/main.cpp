/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * Created on March 16, 2016, 10:05 AM
 * This program alphabetizes names given by the user.
 */

#include <cstdlib>
#include <iostream>
#include <cstring>

using namespace std;

int main(int argc, char** argv) {

    //Declare Variables
    char name1[12]; //First name
    char name2[12]; //Second name
    char name3[12]; //Third name
    
    //Input variables
    cout<<"Enter the three names you want alphabetized, separated by spaces."
            <<endl;
    cin>>name1>>name2>>name3;
    cout<<" "<<endl;
    
    //Alphabetize and Output
    if(strcmp(name1,name2)<0)
        if(strcmp(name1,name3)<0)
            if(strcmp(name2,name3)<0)
            cout<<name1<<" "<<name2<<" "<<name3<<endl; //123
    if(strcmp(name2,name1)<0)
        if(strcmp(name2,name3)<0)
            if(strcmp(name3,name1)<0)
            cout<<name2<<" "<<name3<<" "<<name1<<endl; //231
    if(strcmp(name3,name1)<0)
        if(strcmp(name3,name2)<0)
            if(strcmp(name1,name2)<0)
            cout<<name3<<" "<<name1<<" "<<name2<<endl; //312
    if(strcmp(name3,name2)<0)
        if(strcmp(name3,name1)<0)
            if(strcmp(name2,name1)<0)
            cout<<name3<<" "<<name2<<" "<<name1<<endl; //321
    if(strcmp(name2,name1)<0)
        if(strcmp(name2,name3)<0)
            if(strcmp(name1,name3)<0)
            cout<<name2<<" "<<name1<<" "<<name3<<endl; //213
    if(strcmp(name1,name2)<0)
        if(strcmp(name1,name3)<0)
            if(strcmp(name3,name2)<0)
            cout<<name1<<" "<<name3<<" "<<name2<<endl; //132
    
    return 0;
}

