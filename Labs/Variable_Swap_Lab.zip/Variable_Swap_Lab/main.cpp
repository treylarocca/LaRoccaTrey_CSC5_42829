/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program replicates the variable swap illustrated by Dr. Lehr on the 
 * white board.
 * Created on March 14, 2016, 10:40 AM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Program purpose prompt
    cout<<"This program replicates the variable swap illustrated by Dr. Lehr on"
    " the white board."<<endl;
    cout<<" "<<endl;
    
    //Declare variables
    int a(2); //variable a has a value of 2
    int b(3); //variable b has a value of 3
    
    //Output original variable values
    cout<<"Original value of a: "<<a<<endl;
    cout<<"Original value of b: "<<b<<endl;
    cout<<" "<<endl;
    
    //Swap variables
    a=a^b;
    b=a^b;
    a=a^b;
    
    //Output swapped variable values
    cout<<"New value of a: "<<a<<endl;
    cout<<"New value of b: "<<b<<endl;
    
    return 0;
}

