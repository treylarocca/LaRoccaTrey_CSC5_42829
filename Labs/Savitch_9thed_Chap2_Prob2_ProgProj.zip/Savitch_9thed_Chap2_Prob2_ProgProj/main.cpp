/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 *
 * Created on March 9, 2016, 9:02 AM
 */

#include <cstdlib>
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {

    //Set variable data types
    float osalary; //Original salary
    float omsal; //Original monthly salary
    float nsalary; //New salary
    float nmsal; //New monthly salary
    float backpay; //Retroactive pay
    float iperc; //Percentage of increase
    float perc; //Percentage of increase divided by 100 for calculations
    float salinc; //Salary increase($)
    
    //Input data
    cout<<"What was the original salary?"<<endl;
    cin>>osalary;
    cout<<"What is the percentage of increase? (Do not add % symbol)"<<endl;
    cin>>iperc;
    
    //Calculations
    perc=iperc/100; //alter percentage for ease of calculation
    omsal=osalary/12; //calculate original monthly salary
    salinc=osalary*perc; //calculate salary increase
    nsalary=osalary+salinc; //calculate new salary
    nmsal=nsalary/12; //calculate new monthly salary
    backpay=(nsalary-osalary)/2; //calculate back pay
    
    //Output results        
    cout<<" "<<endl;
    cout<<"Original Salary: $"<<osalary<<endl;
    cout<<"Original Monthly Salary: $"<<omsal<<endl;
    cout<<"Percentage of Salary Increase: "<<iperc<<"%"<<endl;
    cout<<"Salary increase in dollars: $"<<salinc<<endl;
    cout<<"New salary: $"<<nsalary<<endl;
    cout<<"New monthly salary: $"<<nmsal<<endl;
    cout<<"Retroactive Pay Owed: $"<<backpay<<endl;
    
    return 0;
}

