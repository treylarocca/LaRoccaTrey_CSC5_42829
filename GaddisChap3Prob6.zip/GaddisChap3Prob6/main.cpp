/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the percentage of males and females in a class.
 * Created on February 28, 2016, 3:22 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {

    //Set data types for the number of males and females, the total number of 
    //students, and the final percentage of both.
    float nom, nof, nos, pom, pof;
    
    //Input classroom registration figures.
    cout<<"Enter the number of male students enrolled in the class"<<endl;
    cin>>nom;
    cout<<"Enter the number of female students enrolled in the class"<<endl;
    cin>>nof;
    
    //Calculate percentages
    nos=nom+nof;
    pom=(nom/nos)*100;
    pof=(nof/nos)*100;
    cout<<"The class is "<<setprecision(0)<<fixed<<
            pom<<"% male, and "<<setprecision(0)<<fixed<<pof<<"% female."<<endl;
          
    return 0;
}

