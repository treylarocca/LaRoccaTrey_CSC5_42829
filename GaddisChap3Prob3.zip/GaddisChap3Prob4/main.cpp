/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates income from ticket sales of differing prices.
 * Created on February 28, 2016, 1:36 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {

    //Set variable types for Class A, B, and C tickets, and income.
    int cat, cbt, cct;
    float income;
    
    //Receive sales figures
    cout<<"How many Class A tickets were sold?"<<endl;
    cin>>cat;
    cout<<"How many Class B tickets were sold?"<<endl;
    cin>>cbt;
    cout<<"How many Class C tickets were sold?"<<endl;
    cin>>cct;
    
    //Count 'dat money
    income=(cat*15)+(cbt*12)+(cct*9);
    cout<<"Your total income is $"<<setprecision(2)<<fixed<<income<<endl;
              
    return 0;
}

