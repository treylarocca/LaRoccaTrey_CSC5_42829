/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program tells the user the amount of ingredients needed to make 
 * their desired amount of cookies
 * Created on February 28, 2016, 4:23 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {

    //Set data type for cookies in the recipe, and number of cookies desired.
    int cookd;
    //Set data types for each ingredient 
    float cos, cob, cof, fcos, fcob, fcof;
   
    //Determine how many cookies are to be made
    cout<<"How many cookies do you want to make?"<<endl;
    cin>>cookd;
    
    //Calculate ingredients needed
    cos=1.5/48;
    cob=1.0/48;
    cof=2.5/48;
    fcos=cookd*cos;
    fcob=cookd*cob;
    fcof=cookd*cof;
    cout<<"To make "<<cookd<<" cookies, you will need "<<fcos<<
            " cups of sugar, "<<fcob<<" cups of butter, and "<<
            fcof<<" cups of flour."<<endl;
    
    return 0;
}

