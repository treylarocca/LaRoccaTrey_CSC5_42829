/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the average rainfall of 3 months given by user.
 * Created on February 28, 2016, 2:56
 */

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char** argv) {
    
    //Set variable types for month names, amount of rain, and average
    string month1, month2, month3;
    float m1r, m2r, m3r, average;
    
    //Receive rain data
    cout<<"Enter the name of month #1"<<endl;
    cin>>month1;
    cout<<"Enter the amount of rainfall during "<<month1<<endl;
    cin>>m1r;
    cout<<"Enter the name of month #2"<<endl;
    cin>>month2;
    cout<<"Enter the amount of rainfall during "<<month2<<endl;
    cin>>m2r;
    cout<<"Enter the name of month #3"<<endl;
    cin>>month3;
    cout<<"Enter the amount of rainfall during "<<month3<<endl;
    cin>>m3r;
    
    //Calculate average rainfall
    average=(m1r+m2r+m3r)/3;
    cout<<"The average rainfall for "<<month1<<", "<<month2<<", and "<<month3<<
            "is "<<average<<" inches."<<endl;
           
    return 0;
}

