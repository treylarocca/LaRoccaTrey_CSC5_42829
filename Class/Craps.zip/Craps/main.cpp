/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * Play craps.
 * Created on April 27, 2016, 8:00 AM
 */

#include <cstdlib>
#include <iostream> //Rand and Set Random
#include <ctime> //utilize time to set random

using namespace std;

int main(int argc, char** argv) {
    
    //Set random number seed for variability
    srand(static_cast<unsigned int>(time(0)));

    //Declare Variables
    unsigned int nThrows(0); //Number of Throws
    unsigned short nGames(36000); //36000 games
    unsigned short wins(0), losses(0);
    
    //Throw the dice
    for(unsigned short game=1;game<=nGames;game++){
        //Randomly Generate Throw and sum
        unsigned short die1=rand()%6+1; //1-6
        unsigned short die2=rand()%6+1; //1-6
        unsigned short sumDie=die1+die2; //2-12
        nThrows++;
        if(sumDie==7||sumDie==11)wins++;
        else if(sumDie==2||sumDie==3||sumDie==12)losses++;
        else{
            //Declare variable to end game
            bool thrwAgn;
            
            do{
                thrwAgn=true;
                //Randomly Generate Throw and sum
                unsigned short die1=rand()%6+1; //1-6
                unsigned short die2=rand()%6+1; //1-6
                unsigned short sumDie2=die1+die2; //2-12
                nThrows++;
                if(sumDie==sumDie2){
                    wins++;
                    thrwAgn=!thrwAgn;
                }
                else if(sumDie2==7){
                    losses++;
                    thrwAgn=!thrwAgn;
                }
                
            }while(thrwAgn);
        }
    }
    
    //Output Results
    cout<<"Total number of games: "<<(wins+losses)<<endl;
    cout<<"Number of wins: "<<wins<<endl;
    cout<<"Number of losses: "<<losses<<endl;
    cout<<"Percentage of wins: "<<(100.0f*wins/nGames)<<"%"<<endl;
    cout<<"Percentage of losses: "<<(100.0f*losses/nGames)<<"%"<<endl;
    cout<<"Average throws per game: "<<(1.0f*nThrows/nGames)<<endl;
    
    return 0;
}

