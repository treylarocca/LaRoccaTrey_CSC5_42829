/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program illustrates the Rule of 72 by way of a for loop.
 * Created on March 28, 2016, 8:02 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program illustrates the Rule of 72 by way of a while loop."
            <<endl;
    cout<<endl;

    //Declare variables
    float presVal(100.0f); //Present value of money in savings account ($100)
    float futVal=presVal; //Future value
    float intRate(0.05f); //Savings account interest rate (5%)
    float nComp; //Number of compounding periods by rule of 72
    int nYears; //Comparison of calculation to the rule of 72
    
    //Calculate approximate number of years to double by rule of 72
    nComp=0.72f/intRate;
    
    //Output inputs and label the table
    cout<<"Present value: $"<<setprecision(2)<<fixed<<presVal<<endl;
    cout<<"Interest Rate: "<<setprecision(0)<<fixed<<intRate*100<<"%"<<endl;
    cout<<endl;
    cout<<setw(3)<<"Years "<<setprecision(2)<<fixed<<setw(14)<<
            "Future Value"<<endl;
    
    //Loop each year until the future value is 2x the present value    
    for(nYears=1;futVal<2*presVal;nYears++){
        futVal*=(1+intRate);
        cout<<setw(3)<<nYears<<setw(8)<<" $"<<futVal<<endl;
    }
    
    //Output results
    cout<<endl;
    cout<<"By the Rule of 72, it will take "<<nComp<<" years to double the "
            "money in your savings account."<<endl;
    cout<<"Future value: $"<<setprecision(2)<<fixed<<futVal<<endl;
    cout<<"Number of years to more than double: "<<nYears-1<<endl;
    
    return 0;
}

