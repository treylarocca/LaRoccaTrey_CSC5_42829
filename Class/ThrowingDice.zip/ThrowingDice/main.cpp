/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * Randomizer to generate dice throw.
 * Created on April 27, 2016, 8:00 AM
 */

#include <cstdlib>
#include <iostream> //Rand and Set Random
#include <ctime> //utilize time to set random

using namespace std;

int main(int argc, char** argv) {
    
    //Set random number seed for variability
    srand(static_cast<unsigned int>(time(0)));

    //Declare Variables
    char sumDie; //Sum of dice rolls
    char die1; //Die 1 roll value
    char die2; //Die 2 roll value
    unsigned short nThrows(36000); //36000 throws
    unsigned short freq2(0), freq3(0), freq4(0), freq5(0), freq6(0), freq7(0), 
            freq8(0), freq9(0), freq10(0), freq11(0), freq12(0);
    
    //Throw the dice
    for(unsigned short thrwDie=1;thrwDie<=nThrows;thrwDie++){
        //Randomly Generate Throw and sum
        die1=rand()%6+1; //1-6
        die2=rand()%6+1; //1-6
        sumDie=die1+die2; //2-12
        switch(sumDie){
            case 2:freq2++;break;
            case 3:freq3++;break;
            case 4:freq4++;break;
            case 5:freq5++;break;
            case 6:freq6++;break;
            case 7:freq7++;break;
            case 8:freq8++;break;
            case 9:freq9++;break;
            case 10:freq10++;break;
            case 11:freq11++;break;
            case 12:freq12++;break;
            default:cout<<"Bad Result."<<endl;
            
        }
    }
    
    //Output Results
    cout<<"Total number of dice throws: "<<(freq2+freq3+freq4+freq5+freq6+freq7
            +freq8+freq9+freq10+freq11+freq12)<<endl; //Should ALWAYS be 36000
    cout<<"Times 2 was thrown: "<<freq2<<endl;
    cout<<"Times 3 was thrown: "<<freq3<<endl;
    cout<<"Times 4 was thrown: "<<freq4<<endl;
    cout<<"Times 5 was thrown: "<<freq5<<endl;
    cout<<"Times 6 was thrown: "<<freq6<<endl;
    cout<<"Times 7 was thrown: "<<freq7<<endl;
    cout<<"Times 8 was thrown: "<<freq8<<endl;
    cout<<"Times 9 was thrown: "<<freq9<<endl;
    cout<<"Times 10 was thrown: "<<freq10<<endl;
    cout<<"Times 11 was thrown: "<<freq11<<endl;
    cout<<"Times 12 was thrown: "<<freq12<<endl;
    
    return 0;
}

