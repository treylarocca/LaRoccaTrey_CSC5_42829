/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program offers a menu for Assignment 4 (Gaddis8thEdchap5 Problems 1-10)
 * Created on March 30, 2016, 9:46 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program offers a menu for Assignment 4. "
            "(Gaddis8thEdchap5 Problems 1-10)"<<endl;
    cout<<endl;
    
    //Declare loop variable
    int choice; //Menu user's choice of problem
    
    //Menu format
    do{
    
    //Receive choice
    cout<<"Type 1 to run program 1."<<endl;
    cout<<"Type 2 to run program 2."<<endl;
    cout<<"Type 3 to run program 3."<<endl;
    cout<<"Type 4 to run program 4."<<endl;
    cout<<"Type 5 to run program 5."<<endl;
    cout<<"Type 6 to run program 6."<<endl;
    cout<<"Type 7 to run program 7."<<endl;
    cout<<"Type 8 to run program 8."<<endl;
    cout<<"Type 9 to run program 9."<<endl;
    cout<<"Type 10 to run program 10."<<endl;
    cout<<endl;
    cout<<"Type anything else to initiate exit."<<endl;
    cin>>choice;
    cout<<endl;
    
    //Run chosen program
        switch(choice){
            
            case 1:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program gives the sum of all numbers between a positive integer and 1.
 * Created on April 2, 2016, 3:42 PM
 */

    //Purpose Prompt
    cout<<"This program gives the sum of all numbers between a positive integer"
            " and 1."<<endl;
    cout<<endl;
    
    //Declare variables
    int inpNum; //Inputted number
    int runCnt; //Running count of sums
    int sum(0); //Final sum
    
    //Receive inputs
    cout<<"Input a positive integer to be the cap for all numbers added."<<endl;
    cin>>inpNum;
    cout<<endl;
    
    //Validate Input
    while(inpNum<1){
        
        cout<<"Error! Please input a positive integer."<<endl;
        cin>>inpNum;
        cout<<endl;
    }
    
    //Get sum
    for (runCnt=1;runCnt<=inpNum;runCnt++){
        
        sum+=runCnt;
    }
    
    //Output results
    cout<<"The sum of all numbers between 1 and "<<inpNum<<" is "<<sum<<
            "."<<endl;
    cout<<endl;
    
                break;
            }
            
            case 2:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program Displays ASCII characters 0-127, with 16 characters on each line
 * Created on April 2, 2016, 3:42 PM
 */

    //Purpose Prompt
    cout<<"This program Displays ASCII characters 0-127, with 16 characters on "
            "each line."<<endl;
    cout<<endl;
    
    //Declare variables
    int ascii(32); //ASCII value
    char asciiC; //ASCII character
    
    
    //Output ASCII characters
    while (ascii>=0&&ascii<16){
        
        asciiC=static_cast<char>(ascii);
        cout<<asciiC<<" | ";
        ascii++;
    }
    cout<<endl;
    
     while (ascii>=16&&ascii<32){
        
        asciiC=static_cast<char>(ascii);
        cout<<asciiC<<" | ";
        ascii++;
    }
    cout<<endl;
    
     while (ascii>=32&&ascii<48){
        
        asciiC=static_cast<char>(ascii);
        cout<<asciiC<<" | ";
        ascii++;
    }
    cout<<endl;
    
     while (ascii>=48&&ascii<64){
        
        asciiC=static_cast<char>(ascii);
        cout<<asciiC<<" | ";
        ascii++;
    }
    cout<<endl;
    
     while (ascii>=64&&ascii<80){
        
        asciiC=static_cast<char>(ascii);
        cout<<asciiC<<" | ";
        ascii++;
    }
    cout<<endl;
    
     while (ascii>=80&&ascii<96){
        
        asciiC=static_cast<char>(ascii);
        cout<<asciiC<<" | ";
        ascii++;
    }
    cout<<endl;
    
     while (ascii>=96&&ascii<112){
        
        asciiC=static_cast<char>(ascii);
        cout<<asciiC<<" | ";
        ascii++;
    }
    cout<<endl;
    
     while (ascii>=112&&ascii<128){
        
        asciiC=static_cast<char>(ascii);
        cout<<asciiC<<" | ";
        ascii++;
    }
    cout<<endl;
    cout<<endl;
                break;
            }
            
            case 3:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program displays how much the ocean will have risen each year for the 
 * next 25 years.
 * Created on April 2, 2016, 3:42 PM
 */

    //Purpose Prompt
    cout<<"This program displays how much the ocean will have risen each year "
            "for the next 25 years."<<endl;
    cout<<endl;
    
    //Declare variables
    int year(1); //Number of years that has passed
    float rise; //The ocean's rise in millimeters
    
    //Set Table Structure
    cout<<setw(6)<<"Year"<<setw(12)<<"Rise(mm)"<<endl;
    
    //Display rise each year
    while(year>=1&&year<=25){
        
        rise=1.5*year;
        cout<<setw(4)<<year<<setw(11)<<rise<<endl;
        ++year;
        
    }
    cout<<endl;
                break;
            }
            
            case 4:{
/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program displays how many calories are burned after 5, 10, 15, 20, 25, 
 * and 30 minutes.
 * Created on April 2, 2016, 3:42 PM
 */

    //Purpose Prompt
    cout<<"This program displays how many calories are burned after 5, 10, 15,"
            " 20, 25, and 30 minutes."<<endl;
    cout<<endl;
    
    //Declare variables
    int min(5); //Number of minutes on the treadmill
    float calBurn; //Calories burned
    
    //Set Table Structure
    cout<<setw(8)<<"Minutes"<<setw(20)<<"Calories Burned"<<endl;
    
    //Display calories burned for minute marks
    while(min>=5&&min<=30){
        
        calBurn=min*3.6;
        cout<<setw(6)<<min<<setw(16)<<calBurn<<endl;
        min+=5;
    }
    
    cout<<endl;
                break;
            }
            
            case 5:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program displays the rise in membership fee for a country club over the
 *  next 6 years.
 * Created on April 2, 2016, 3:42 PM
 */

    //Purpose Prompt
    cout<<"This program displays the rise in membership fee for a country club"
            " over the next 6 years."<<endl;
    cout<<endl;
    
    //Declare variables
    int years(1); //Number of years passed
    float percInc(0.04); //Percentage of increase in fee each year (4%)
    float memFee(2500); //Membership fee of $2500
    
    //Set Table Structure
    cout<<setw(6)<<"Year"<<setw(18)<<"Membership Fee"<<endl;
    
    //Display membership fee for each year passed
    while(years>=1&&years<=6){
        
        memFee+=(memFee*percInc);
        cout<<setw(5)<<years<<setw(14)<<"$"<<memFee<<endl;
        years++;
    }
    cout<<endl;
                break;
            }
            
            case 6:{
                cout<<"6"<<endl;
                cout<<endl;
                break;
            }
            
            case 7:{
                cout<<"7"<<endl;
                cout<<endl;
                break;
            }
            
            case 8:{
                cout<<"8"<<endl;
                cout<<endl;
                break;
            }
            
            case 9:{
                cout<<"9"<<endl;
                cout<<endl;
                break;
            }
            
            case 10:{
                cout<<"10"<<endl;
                cout<<endl;
                break;
            }
            
            default:{
                cout<<"Exit initiated."<<endl;
                break;
            }
            
        };
    }while(choice>=1&&choice<=10);

    return 0;
}

