/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program offers a menu for Assignment 4 (Gaddis8thEdchap5 Problems 1-10)
 * Created on March 30, 2016, 9:46 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program offers a menu for Assignment 4. "
            "(Gaddis8thEdchap5 Problems 1-10)"<<endl;
    cout<<endl;
    
    //Declare loop variable
    int choice; //Menu user's choice of problem
    
    //Menu format
    do{
    
    //Receive choice
    cout<<"Type 1 to run program 1."<<endl;
    cout<<"Type 2 to run program 2."<<endl;
    cout<<"Type 3 to run program 3."<<endl;
    cout<<"Type 4 to run program 4."<<endl;
    cout<<"Type 5 to run program 5."<<endl;
    cout<<"Type 6 to run program 6."<<endl;
    cout<<"Type 7 to run program 7."<<endl;
    cout<<"Type 8 to run program 8."<<endl;
    cout<<"Type 9 to run program 9."<<endl;
    cout<<"Type 10 to run program 10."<<endl;
    cout<<endl;
    cout<<"Type anything else to initiate exit."<<endl;
    cin>>choice;
    cout<<endl;
    
    //Run chosen program
        switch(choice){
            
            case 1:{
                cout<<"1"<<endl;
                cout<<endl;
                break;
            }
            
            case 2:{
                cout<<"2"<<endl;
                cout<<endl;
                break;
            }
            
            case 3:{
                cout<<"3"<<endl;
                cout<<endl;
                break;
            }
            
            case 4:{
                cout<<"4"<<endl;
                cout<<endl;
                break;
            }
            
            case 5:{
                cout<<"5"<<endl;
                cout<<endl;
                break;
            }
            
            case 6:{
                cout<<"6"<<endl;
                cout<<endl;
                break;
            }
            
            case 7:{
                cout<<"7"<<endl;
                cout<<endl;
                break;
            }
            
            case 8:{
                cout<<"8"<<endl;
                cout<<endl;
                break;
            }
            
            case 9:{
                cout<<"9"<<endl;
                cout<<endl;
                break;
            }
            
            case 10:{
                cout<<"10"<<endl;
                cout<<endl;
                break;
            }
            
            default:{
                cout<<"Exit initiated."<<endl;
                break;
            }
            
        };
    }while(choice>=1&&choice<=10);

    return 0;
}

