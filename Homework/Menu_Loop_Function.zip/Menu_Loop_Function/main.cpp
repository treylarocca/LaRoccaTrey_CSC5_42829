/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program offers a menu for Assignment 4 (Gaddis8thEdchap5 Problems 1-10)
 * Created on March 30, 2016, 9:46 AM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>
#include <cmath>

using namespace std;

//Function Prototypes
void menu();
void prob1();
void prob2();
void prob3();


int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program offers a menu for Assignment 4. "
            "(Gaddis8thEdchap5 Problems 1-10)"<<endl;
    cout<<endl;
    
    //Declare loop variable
    int choice; //Menu user's choice of problem
    
    //Menu format
    do{
    
    //Receive choice
        menu();
        cin>>choice;
        cout<<endl;
    
    //Run chosen program
        switch(choice){
            
            case 1:prob1();break;
            
            case 2:{
                
                break;
            }
            
            case 4:{

                break;
            }
            
            case 5:{
                
                break;
            }
            
            case 6:{
                cout<<"6"<<endl;
                cout<<endl;
                break;
            }
            
            case 7:{
                cout<<"7"<<endl;
                cout<<endl;
                break;
            }
            
            case 8:{
                cout<<"8"<<endl;
                cout<<endl;
                break;
            }
            
            case 9:{
                cout<<"9"<<endl;
                cout<<endl;
                break;
            }
            
            case 10:{
                cout<<"10"<<endl;
                cout<<endl;
                break;
            }
            
            default:{
                cout<<"Exit initiated."<<endl;
                break;
            }
            
        };
    }while(choice>=1&&choice<=10);

    return 0;
}

//000000011111111112222222222333333333344444444445555555555666666666677777777778
//345678901234567890123456789012345678901234567890123456789012345678901234567890
/*                               Menu
/*Inputs
 *      None
 *Outputs
 *      None  
 */
void menu(){
    
    //Display menu
    cout<<"Type 1 to run program 1."<<endl;
    cout<<"Type 2 to run program 2."<<endl;
    cout<<"Type 3 to run program 3."<<endl;
    cout<<"Type 4 to run program 4."<<endl;
    cout<<"Type 5 to run program 5."<<endl;
    cout<<"Type 6 to run program 6."<<endl;
    cout<<"Type 7 to run program 7."<<endl;
    cout<<"Type 8 to run program 8."<<endl;
    cout<<"Type 9 to run program 9."<<endl;
    cout<<"Type 10 to run program 10."<<endl;
    cout<<endl;
    cout<<"Type anything else to initiate exit."<<endl;

}

/*                               Problem 1
/*Inputs
 *      None
 *Outputs
 *      None  
 */
void prob1(){
    cout<<"1"<<endl;
}

void prob2(){
    
}

void prob3(){
    
}