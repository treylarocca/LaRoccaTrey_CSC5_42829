/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the average rainfall of 3 months given by user.
 * Created on February 28, 2016, 2:56
 */

#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program calculates the average rainfall of 3 months given by "
            "user."<<endl;
    cout<<" "<<endl;
    
    //Declare Variables
    string month1, month2, month3; //Month Names
    float m1r, m2r, m3r; //Rainfall each month
    float average; //Average rainfall
    
    //Receive rain data
    cout<<"Enter the name of month #1"<<endl;
    cin>>month1;
    cout<<"Enter the amount of rainfall(inches) during "<<month1<<endl;
    cin>>m1r;
    cout<<"Enter the name of month #2"<<endl;
    cin>>month2;
    cout<<"Enter the amount of rainfall(inches) during "<<month2<<endl;
    cin>>m2r;
    cout<<"Enter the name of month #3"<<endl;
    cin>>month3;
    cout<<"Enter the amount of rainfall(inches) during "<<month3<<endl;
    cin>>m3r;
    cout<<" "<<endl;
    
    //Calculate average rainfall
    average=(m1r+m2r+m3r)/3;
    
    //Output Results
    cout<<"The average rainfall for "<<month1<<", "<<month2<<", and "<<month3<<
            " is "<<average<<" inches."<<endl;
           
    return 0;
}

