/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program Calculates the net and gross box office profits, as well
 * as the amount paid to the distributor of any movie in the LaRocca theater.
 * Created on February 28, 2016, 5:28 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main(int argc, char** argv) {

    //Set data types for adult tickets, child tickets, net and gross profits,
    // money paid to distributor, and movie name.
    int at, ct;
    float gp, npp, np, dp;
    string mn;
    
    //Input movie and sales data
    cout<<"Enter the name of the movie"<<endl;
    getline(cin,mn);
    cout<<"How many adult tickets were sold for "<<mn<<"?"<<endl;
    cin>>at;
    cout<<"How many child tickets were sold for "<<mn<<"?"<<endl;
    cin>>ct;
    
    //Determine gross profit
    gp=(10*at)+(6*ct);
    
    //Watch the money slip through our fingers (determine net profit)
    npp=gp*(4.0/5.0);
    np=gp-npp;
    
    //Display first row
    cout<<"Movie Name:"<<setw(29)<<mn<<endl;
    cout<<"Adult tickets Sold:"<<setw(21)<<at<<endl;
    cout<<"Child tickets Sold:"<<setw(21)<<ct<<endl;
    cout<<setprecision(2)<<fixed;
    cout<<"Gross Box Office Profit($):"<<setw(13)<<gp<<endl;
    cout<<"Net Box Office Profit($):"<<setw(15)<<np<<endl;
    cout<<"Amount Paid to Distributor($):"<<setw(10)<<npp<<endl;
            
    return 0;
}

