/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the number of widgets on a pallet based on weight.
 * Created on February 28, 2016, 6:28 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program calculates the number of widgets on a pallet based on "
            "weight."<<endl;
    cout<<" "<<endl;

    //Declare variables
    int nw; //Number of widgets
    float wow; //Weight of widgets
    float wpa; //Weight of pallet alone
    float wpww; //Weight of pallet with widgets
    
    //Input weight data
    cout<<"How much does the pallet weigh, by itself, in pounds?"<<endl;
    cin>>wpa;
    cout<<"How much does the pallet weigh, in pounds, with all widgets on it"
            <<endl;
    cin>>wpww;
    
    //Calculate number of widgets
    wow=wpww-wpa;
    nw=wow/12.5;
    
    //Output results
    cout<<"There are "<<nw<<" widgets on the pallet."<<endl;
        
    return 0;
}

