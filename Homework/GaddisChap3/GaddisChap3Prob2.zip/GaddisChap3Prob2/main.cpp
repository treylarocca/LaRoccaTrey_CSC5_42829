/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program tells the user their vehicle's gas mileage
 * Created on February 27, 2016, 3:06 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Declare Variables
    //Tank Capacity, Miles Per Full Tank, Gas Mileage
    int tankcap, mpt, mpg;
    
    
    //Calculate Gas Mileage
    cout<<"Enter the capacity of your vehicle's gas tank in gallons"<<endl;
    cin>> tankcap;
    cout<<"Enter the number of miles you can drive on one full tank"<<endl;
    cin>> mpt;
    mpg = mpt/tankcap;
    cout<<"Your Vehicle's gas mileage in miles-per-gallon:"<<endl;
    cout<< mpg;        
            
    return 0;
}

