/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the average of 5 user-inputed test scores.
 * Created on February 28, 2016, 2:45 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {
    
    //Declare variable
    cout<<"This program calculates the average of 5 user-inputed test scores."
            <<endl;
    cout<<" "<<endl;

    //Set variable types for scores 1-5 and the final average
    int s1, s2, s3, s4, s5; //Test scores
    float average; //Pretty much self-explanatory
    
    //Input test scores
    cout<<"Enter test score #1"<<endl;
    cin>>s1;
    cout<<"Enter test score #2"<<endl;
    cin>>s2;
    cout<<"Enter test score #3"<<endl;
    cin>>s3;
    cout<<"Enter test score #4"<<endl;
    cin>>s4;
    cout<<"Enter test score #5"<<endl;
    cin>>s5;
            
    //Calculate just how poorly your students prepared
    average=(s1+s2+s3+s4+s5)/5;
    
    //Output Results
    cout<<"Your students achieved an average score of "<<
            setprecision(1)<<fixed<<average<<"."<<endl;
    
    return 0;
}

