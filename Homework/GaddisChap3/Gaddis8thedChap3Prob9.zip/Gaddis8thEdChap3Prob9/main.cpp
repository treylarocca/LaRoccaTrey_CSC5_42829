/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates how many calories you have consumed by eating cookies
 * Created on February 28, 2016, 6:44 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program calculates how many calories you have consumed by "
            "eating cookies"<<endl;
    cout<<" "<<endl;

    //Set data types for cookies eaten, and total calories consumed.
    int cookeat; //Number of cookies consumed
    int totcal; //Number of calories consumed
    
    //Input the number of cookies consumed
    cout<<"How many cookies did you eat? "
            "(I am sentient and will know if you lie)"<<endl;
    cin>>cookeat;
    
    //Calculate number of cookies eaten
    totcal=cookeat*100;
    
    //Output results
    cout<<"You consumed "<<totcal<<" calories by eating "<<cookeat<<" cookies."
            <<endl;
    cout<<" "<<endl;
    
    //Shame the user
    cout<<"Are you proud of yourself?"<<endl;
    
    
                       
    return 0;
}

