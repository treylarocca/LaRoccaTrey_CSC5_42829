/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program tells the user the minimum insurance amount they should buy
 * for their property.
 * Created on March 18, 2016, 10:14 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program tells the user the minimum insurance amount they should "
            "buy for their property."<<endl;
    cout<<" "<<endl;

    //Declare Variables
    float mip(0.8); //Minimum insurance percentage (80%)
    float repCost; //Replacement cost of the property
    float insVal; //Recommended minimum insurance value
    
    //Input cost
    cout<<"Enter what it would cost (in dollars) to replace your property."
            <<endl;
    cin>>repCost;
    cout<<" "<<endl;
    
    //Calculate recommended minimum insurance policy
    insVal=repCost*mip;
    
    //Output results
    cout<<"For your property, we recommend you purchase at least $"
            <<setprecision(2)<<fixed<<insVal<<" in insurance."<<endl;
    
    return 0;
}

