/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program tells the user the amount of ingredients needed to make 
 * their desired amount of cookies
 * Created on February 28, 2016, 4:23 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program tells the user the amount of ingredients needed to "
            "make their desired amount of cookies."<<endl;
    cout<<" "<<endl;

    //Declare variables
    int cookd; //Number of cookies desired 
    float COS; //Cups of sugar per cookie
    float COB; //Cups of butter per cookie
    float COF; //Cups of flour per cookie
    float fcos; //Final cups of sugar
    float fcob; //Final cups of butter
    float fcof; //Final cups of flour
    
    //Set constant values
    COS=1.5/48;
    COB=1.0/48;
    COF=2.75/48;
    
    //Determine how many cookies are to be made
    cout<<"How many cookies do you want to make?"<<endl;
    cin>>cookd;
    
    //Calculate ingredients needed
    fcos=cookd*COS;
    fcob=cookd*COB;
    fcof=cookd*COF;
    
    //Output Results
    cout<<"To make "<<setprecision(2)<<fixed<<cookd<<" cookies, you will need "
            <<setprecision(2)<<fixed<<fcos<<" cups of sugar, "<<setprecision(2)
            <<fixed<<fcob<<" cups of butter, and "<<setprecision(2)<<fixed<<
            fcof<<" cups of flour."<<endl;
    
    return 0;
}

