/* 
 * File:   main.cpp
 * Author: Trey
 * This program tells the user their vehicle's gas mileage.
 * Created on March 18, 2016, 4:57 PM
 */

#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;

int main(int argc, char** argv) {

    //Purpose Prompt
    cout<<"This program tells the user their vehicle's gas mileage."<<endl;
    cout<<" "<<endl;
    
    //Declare Variables
    int tankCap; //Vehicle's gas tank capacity
    int mpt; //Miles per full tank
    int mpg; //Gas mileage
    
    //Receive Input values
    cout<<"Enter your vehicle's gas tank capacity in gallons."<<endl;
    cin>>tankCap;
    cout<<"Enter the number of miles that can be driven in one full tank."
            <<endl;
    cin>>mpt;
    
    //Calculate Gas Mileage
    mpg=mpt/tankCap;
    
    //Output Results
    cout<<"Your vehicle gets "<<mpg<<" miles per gallon."<<endl;
    
    return 0;
}

