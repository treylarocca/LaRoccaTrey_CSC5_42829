/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This Program tells a customer how much credit they have left out of their
 * max credit of $500
 * Created on February 27, 2016, 2:20 PM
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Declare Variables
    //Credit Used and Remaining Credit
    int crdused, crdrem;
    
    //Calculate Remaining credit
    cout<<"Enter the amount of credit used in dollars."<<endl;
    cin>> crdused;
    crdrem = 500-crdused;
    cout<<"Credit remaining:"<<endl;
    cout<< crdrem;
    
    //Exit Stage Right!
    return 0;
}

