/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the percentage of males and females in a class.
 * Created on March 18, 2016, 6:50 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {
    
    //Purpose Prompt
    cout<<"This program calculates the percentage of males and females in a "
            "class."<<endl;
    cout<<" "<<endl;

    //Declare variables
    int nom; //Number of male students
    int nof; //Number of female students
    int nos; //Total Number of students
    float pom; //Percentage of males
    float pof; //Percentage of females
    
    //Input values
    cout<<"Enter the number of male students in the class."<<endl;
    cin>>nom;
    cout<<"Enter the number of female students in the class."<<endl;
    cin>>nof;
    cout<<" "<<endl;
    
    //Calculate percentages
    nos=nom+nof;
    pom=(static_cast<float>(nom)/static_cast<float>(nos))*100;
    pof=(static_cast<float>(nof)/static_cast<float>(nos))*100;
    
    //Output Results
    cout<<"The class is "<<setprecision(0)<<fixed<<pom<<"% males, and "
            <<setprecision(0)<<fixed<<pof<<"% females."<<endl;
    
    return 0;
}

