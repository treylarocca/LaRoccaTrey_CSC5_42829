/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program displays the size of the data types char, int, float, and double
 * Created on March 4, 2016, 8:20 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Output the sizes of the data types
    cout<<"This program displays the size of the data types char, int, float, "
            "and double."<<endl;
    cout<<" "<<endl;
    cout<<"Size of char: "<<sizeof(char)<<" bytes"<<endl;
    cout<<"Size of int: "<<sizeof(int)<<" bytes"<<endl;
    cout<<"Size of float: "<<sizeof(float)<<" bytes"<<endl;
    cout<<"Size of double: "<<sizeof(double)<<" bytes"<<endl;
    return 0;
}

