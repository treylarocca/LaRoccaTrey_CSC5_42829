/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the amount of sales tax (state & county) on a $95
 * purchase.
 * Created on March 4, 2016, 7:03 PM
 */

#include <cstdlib>
#include <iostream>


using namespace std;

int main(int argc, char** argv) {
    
    //Set variable data types
    int PPRICE; //Original pre-tax purchase price
    float STF, sta; //State tax factor, state tax amount($)
    float CTF, cta; //County tax factor, county tax amount ($)
    float tottax; //Total sales tax on purchase
    
    //Set constant values
    PPRICE=95.00;
    STF=0.04;
    CTF=0.02;
    
    //Calculate sales tax
    sta=STF*PPRICE;
    cta=CTF*PPRICE;
    tottax=sta+cta;
    
    //Output results
    cout<<"This program calculates the amount of sales tax (state & county) on"
            " a $95 purchase."<<endl;
    cout<<"The total sales tax on a $95 dollar purchase is $"<<tottax<<"."
            <<endl;
            
    return 0;
}

