/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program determines how much the ocean level will rise(in millimeters) in
 *  5, 7, and 10 years.
 * Created on March 4, 2016, 7:52 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set variable data types
    float RISE; //Rise in ocean level per year (millimeters)
    float rfy; //Rise after five years
    float rsy; //Rise after seven years
    float rty; //Rise after 10 years
    
    //Set constant value
    RISE=1.5;
    
    //Calculations
    rfy=RISE*5; //Calculate 5-year rise
    rsy=RISE*7; //Calculate 7-year rise
    rty=RISE*10; //Calculate 10-year rise
    
    //Output results
    cout<<"This program determines how much the ocean level will rise"
            "(in millimeters) in 5, 7, and 10 years."<<endl;
    cout<<"Rise after 5 years: "<<rfy<<" mm."<<endl;
    cout<<"Rise after 7 years: "<<rsy<<" mm."<<endl;
    cout<<"Rise after 10 years: "<<rty<<" mm."<<endl;
    return 0;
}

