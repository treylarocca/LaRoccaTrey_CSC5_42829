/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program stores variables as 50 and 100, and their sum as "total"
 * Created on March 1, 2016, 10:05 AM
 */

#include <cstdlib>
#include <iostream>

using namespace std;


int main(int argc, char** argv) {

    //Set variable data types
    int fifty, hundred, total;
    
    //Set variable values
    fifty=50;
    hundred=100;
    total=fifty+hundred;
    
    //output result
    cout<<"This program adds the numbers 50 and 100."<<endl;
    cout<<"The sum of "<<fifty<<" and "<<hundred<<" is "<<total<<"."<<endl;
            
    return 0;
}

