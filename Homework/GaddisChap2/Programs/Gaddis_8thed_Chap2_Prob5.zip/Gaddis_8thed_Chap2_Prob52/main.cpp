/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the average of 28, 32, 37, 24, and 33.
 * Created on March 4, 2016, 7:33 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set variable data types
    int N1; //First number (28)
    int N2; //Second number (32)
    int N3; //Third number (37)
    int N4; //Fourth number (24)
    int N5; //Fifth number (33)
    float sum; //Sum of all 5 numbers
    float avg; //average
    
    //Set constant values
    N1=28;
    N2=32;
    N3=37;
    N4=24;
    N5=33;
    
    //Calculations
    sum=N1+N2+N3+N4+N5; //Calculate sum of all 5 numbers
    avg=sum/5; //Calculate average
    
    //Output results
    cout<<"This program calculates the average of 28, 32, 37, 24, and 33."
            <<endl;
    cout<<"The average of these 5 numbers is "<<avg<<endl;
            
    return 0;
}

