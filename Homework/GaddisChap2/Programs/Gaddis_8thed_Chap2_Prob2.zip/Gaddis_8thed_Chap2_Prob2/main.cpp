/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program determines the amount of money the East Coast branch of a 
 * company will make this year if the company makes $8.6 million.
 * Created on March 4, 2016, 4:45 PM
 */

#include <csdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set data types for variables
    float ECPF; //East Coast percentage factor
    float TCR; //Total company revenue
    float ecr; //East Coast revenue
    
    //Set constant variables
    ECPF=0.58; //58%
    TCR=8.6e6f; //8,600,000
    
    //Calculate total sales
    ecr=TCR*ECPF;
    
    //Output results
    cout<<"This program determines the amount of money (in $) the East Coast"
            " branch of a company will make this year if the company makes"
            " $8.6 million."<<endl;
    cout<<"The East Coast branch made $"<<ecr<<" this year, out of the total "
            "company revenue of $8.6 million."<<endl;
       
    return 0;
}

