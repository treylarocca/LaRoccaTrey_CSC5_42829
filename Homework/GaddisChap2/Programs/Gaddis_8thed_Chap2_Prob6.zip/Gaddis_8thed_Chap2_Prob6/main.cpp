/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates an employee's total annual pay.
 * Created on March 4, 2016, 7:45 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set variable data types
    float PAYAMT; //Pay amount per pay period
    float PAYPERS; //Number of pay periods in a year
    float annpay; //Annual pay
    
    //Set constant values
    PAYAMT=2200.0;
    PAYPERS=26;
    
    //Calculate annual pay
    annpay=PAYAMT*PAYPERS;
    
    //Output results
    cout<<"This program calculates an employee's total annual pay."<<endl;
    cout<<"The employee gets paid $"<<annpay<<"-per-year."<<endl;
            
    return 0;
}

