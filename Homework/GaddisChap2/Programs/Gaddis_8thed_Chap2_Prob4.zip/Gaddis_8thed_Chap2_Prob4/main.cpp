/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the tax and tip on a $88.67 meal, and displays the
 * meal cost, tax amount, tip amount, and total bill.
 * Created on March 4, 2016, 7:18 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {

    //Set data types for variables
    float OMC, mcpt; //Original pre-tax/pre-tip meal cost, meal cost plus tax;
    float TAXF, taxa; //Tax factor, tax amount;
    float TIPF, tipa; //Tip factor, tip amount;
    float totbill; //Total bill;
    
    //Set constant values
    OMC=88.67;
    TAXF=0.0675;
    TIPF=0.2;
    
    //Calculations
    taxa=OMC*TAXF; //Calculate tax amount
    mcpt=OMC+taxa; //Calculate meal cost plus tax
    tipa=mcpt*TIPF; //Calculate tip amount
    totbill=mcpt+tipa; //Calculate total bill
    
    //Output results
    cout<<"This program calculates the tax and tip on a $88.67 meal, and "
            "displays the meal cost, tax amount, tip amount, and total bill."
            <<endl;
    cout<<"Original Meal Cost: $"<<OMC<<endl;
    cout<<"Tax Amount: $"<<setprecision(2)<<fixed<<taxa<<endl;
    cout<<"Tip Amount: $"<<setprecision(2)<<fixed<<tipa<<endl;
    cout<<"Total Bill: $"<<setprecision(2)<<fixed<<totbill<<endl;
    
    return 0;
}

