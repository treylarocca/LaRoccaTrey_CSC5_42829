/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program determines the total cost of a 5-item purchase, and displays the
 * price of each item, the subtotal, and the total price after tax(all in $).
 * Created on March 4, 2016, 8:05 PM
 */

#include <cstdlib>
#include <iostream>
#include <iomanip>

using namespace std;

int main(int argc, char** argv) {

    //Set variable data types
    float P1, P2, P3, P4, P5; //Prices of the five items;
    float STF, sta; //Sales tax factor, sales tax amount;
    float subt, totp; //Subtotal, total price;
    
    //Set constant values
    P1=15.95; //Price of item 1
    P2=24.95; //Price of item 2
    P3=6.95; //Price of item 3
    P4=12.95; //Price of item 4
    P5=3.95; //Price of item 5
    STF=0.07; //7% sales tax factor
    
    //Calculations
    subt=P1+P2+P3+P4+P5; //Calculate subtotal
    sta=subt*STF; //Calculate sales tax amount
    totp=subt+sta; //Calculate total price
    
    //Output results
    cout<<"This program determines the total cost of a 5-item purchase,"<<endl;
    cout<<"and displays the price of each item, the subtotal,"<<endl;
    cout<<"and the total price after tax(all in $)."<<endl;
    cout<<" "<<endl;
    cout<<"Item 1: $"<<P1<<endl;
    cout<<"Item 2: $"<<P2<<endl;
    cout<<"Item 3: $"<<P3<<endl;
    cout<<"Item 4: $"<<P4<<endl;
    cout<<"Item 5: $"<<P5<<endl;
    cout<<" "<<endl;
    cout<<"Subtotal: $"<<subt<<endl;
    cout<<"Sales Tax: $"<<setprecision(2)<<fixed<<sta<<endl;
    cout<<"Total Price: $"<<setprecision(2)<<fixed<<totp<<endl;
    
    return 0;
}

