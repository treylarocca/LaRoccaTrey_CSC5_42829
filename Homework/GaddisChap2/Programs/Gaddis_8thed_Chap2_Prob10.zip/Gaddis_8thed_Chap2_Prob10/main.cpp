/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the gas mileage of a vehicle.
 * Created on March 4, 2016, 8:29 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set data types
    int TCAP; //The vehicle's gas tank capacity
    int MFT; //Amount of miles the vehicle can drive with one full tank
    float mpg; //The vehicle's gas mileage
    
    //Set constant values
    TCAP=15; //The vehicle's gas tank holds 15 gallons
    MFT=375; //The vehicle can drive 375 miles on one full tank
    
    //Calculate gas mileage
    mpg=MFT/TCAP;
    
    //Output results
    cout<<"This program calculates the gas mileage of a vehicle."<<endl;
    cout<<" "<<endl;
    cout<<"The vehicle gets "<<mpg<<" miles-per-gallon."<<endl;
    return 0;
}

