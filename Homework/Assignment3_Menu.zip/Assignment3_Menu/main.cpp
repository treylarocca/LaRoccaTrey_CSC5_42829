/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Display all 10 homework problems in a menu (Gaddis8thEdChap4 Problems 1-10)
 * Modified on March 28, 2016
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare loop variable
    int choice;
    //General Menu Format
    do{
    //Display the selection
    cout<<"Type 1 to solve problem 1"<<endl;
    cout<<"Type 2 to solve problem 2"<<endl;
    cout<<"Type 3 to solve problem 3"<<endl;
    cout<<"Type 4 to solve problem 4"<<endl;
    cout<<"Type 5 to solve problem 5"<<endl;
    cout<<"Type 6 to solve problem 6"<<endl;
    cout<<"Type 7 to solve problem 7"<<endl;
    cout<<"Type 8 to solve problem 8"<<endl;
    cout<<"Type 9 to solve problem 9"<<endl;
    cout<<"Type 10 to solve problem 10"<<endl;

    cout<<"Type anything else to quit with no solutions."<<endl;
    //Read the choice
    cin>>choice;
    //Solve a problem that has been chosen.
    switch(choice){
            case 1:{
/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program takes two numbers and displays which is greater and which is 
 * lesser.
 * Created on March 26, 2016, 10:32 PM
 */

    //Purpose Prompt
    cout<<"This program takes two numbers and displays which is greater and "
            "which is lesser."<<endl;
    cout<<endl;

    //Declare Variables
    float num1, num2; //Inputed numbers
    
    //Input numbers
    cout<<"Enter the two numbers you would like to compare, separated by a "
            "space."<<endl;
    cin>>num1>>num2;
    cout<<endl;
    
    //Compare numbers
    (num1>num2)?
        cout<<"The number "<<num1<<" is greater than the number "<<num2<<"."
                <<endl: 
 
    (num2>num1)?
        cout<<"The number "<<num2<<" is greater than the number "<<num1<<"."
                <<endl: 
    
    (num1=num2)?
        cout<<"The two numbers entered have equal value."<<endl: cout<<endl;
        cout<<endl;
            }
                
                break;
                
            case 2:{
 /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program converts any number 1-10 to Roman numerals.
 * Created on March 28, 2016, 10:00 AM
 */
    
    //Purpose Prompt
    cout<<endl;
    cout<<"This program converts any number 1-10 to Roman numerals."<<endl;
    cout<<endl;

    //Declare Variables
    int num; //Number inputed for conversion
    
    //Input number
    cout<<"Enter the number, between 1 and 10, that you would like to "
            "convert."<<endl;
    cin>>num;
    cout<<endl;
    
    //Validate Input
    if (num<1||num>10){
        cout<<"Please enter a number between 1 and 10."<<endl;
        cin>>num;
        cout<<endl;
    }
    else{}
    
    //Convert to Roman numerals
    switch(num){
        case 1:
            cout<<"The number one is represented as I."<<endl;
            break;
            
        case 2:
            cout<<"The number two is represented as II."<<endl;
            break;
        
        case 3:
            cout<<"The number three is represented as III."<<endl;
            break;
            
        case 4:
            cout<<"The number four is represented as IV."<<endl;
            break;
            
        case 5:
            cout<<"The number five is represented as V."<<endl;
            break;
            
        case 6:
            cout<<"The number six is represented as VI."<<endl;
            break;
            
        case 7:
            cout<<"The number seven is represented as VII."<<endl;
            break;
            
        case 8:
            cout<<"The number eight is represented as VIII."<<endl;
            break;
            
        case 9:
            cout<<"The number nine is represented as IX."<<endl;
            break;
            
        case 10:
            cout<<"The number ten is represented as X."<<endl;
            break;
            
        default:
            cout<<"Error"<<endl;
            break;
    }
    cout<<endl;
    break;

            }
            case 3:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program tells you if an entered date is magic.
 * Created on March 28, 2016, 10:00 AM
 */

    //Purpose Prompt
    cout<<endl;
    cout<<"This program tells you if an entered date is magic."<<endl;
    cout<<endl;

    //Declare Variables
    int month; 
    int day; 
    int year;
    
    //Input date
    cout<<"Enter the date (mm dd yy) you would like to test for magic."<<endl;
    cin>>month>>day>>year;
    cout<<endl;
    
    //Validate Input
    if (month<1||month>12||day<1||day>31){
        cout<<"Please enter a valid date (mm dd yy)."<<endl;
        cin>>month>>day>>year;
        cout<<endl;
    }
    else{
    
    //Test for magic
        if(year==month*day){
            cout<<"The date "<<month<<"/"<<day<<"/"<<year<<" is magic!"<<endl;
            cout<<endl;
        }
        else{
            cout<<"The date "<<month<<"/"<<day<<"/"<<year<<" is not magic."
                    <<endl;
            cout<<endl;
        }}
    break;
            }
            case 4:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program tells you the area of two rectangles, and compares their size.
 * Created on March 28, 2016, 10:00 AM
 */
    
    //Purpose Prompt
    cout<<endl;
    cout<<"This program tells you the area of two rectangles, and compares "
            "their size."<<endl;
    cout<<endl;

    //Declare Variables
    float length1, length2; //Lengths of rectangle 1 and rectangle 2 
    float width1, width2; //Widths of rectangle 1 and rectangle 2 
    float area1, area2; //Areas of both rectangles
    
    //Input date
    cout<<"Enter the length and width in cm of Rectangle 1, separated by a "
            "space."<<endl;
    cin>>length1>>width1;
    cout<<endl;
    cout<<"Enter the length and width in cm of Rectangle 2, separated by a "
            "space."<<endl;
    cin>>length2>>width2;
    cout<<endl;
    
    //Calculate areas
    area1=length1*width1;
    area2=length2*width2;
    
    //Output areas
    cout<<"Area of Rectangle 1: "<<area1<<"cm^2"<<endl;
    cout<<"Area of Rectangle 2: "<<area2<<"cm^2"<<endl;
    cout<<endl;
    
    //Compare areas and output results
    if(area1>area2){
        cout<<"Rectangle 1 has a greater area than Rectangle 2."<<endl;
        cout<<endl;
    }
    else if(area2>area1){
        cout<<"Rectangle 2 has a greater area than Rectangle 1."<<endl;
        cout<<endl;
    }
    else{
        cout<<"The rectangles have equal areas."<<endl;
    }
    break;
            }
            case 5:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates a person's Body Mass Index and tells them if they are
 * overweight or underweight.
 * Created on March 26, 2016, 10:32 PM
 */

    //Purpose Prompt
    cout<<endl;
    cout<<"This program calculates a person's Body Mass Index,"<<endl;
    cout<<"and tells them if they are overweight or underweight."<<endl;
    cout<<endl;

    //Declare Variables
    float weight; //The subject's weight
    float height; //The subject's height
    float bmi; //Body mass index
    
    //Input weight and height
    cout<<"Enter your weight in pounds."<<endl;
    cin>>weight;
    cout<<"Enter your height in inches."<<endl;
    cin>>height;
    cout<<endl;
    
    //Calculate and display body mass index
    bmi=weight*(703/(pow(height,2)));
    cout<<"Body Mass Index: "<<bmi<<endl;
    cout<<endl;
            
    //Judge subject's life choices (overweight or underweight)
    if(bmi>25){
        cout<<"You are overweight. Yes, gyms are expensive, but so is heart "
                "surgery."<<endl;
        cout<<endl;
    }
    else if(bmi<18.5){
        cout<<"You are underweight. Try more McDonald's."<<endl;
        cout<<endl;
    }
    else{
        cout<<"You are healthy... at least in regard to your BMI."<<endl;
    }
    break;
            }
            case 6:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates an objects weight in Newtons.
 * Created on March 26, 2016, 10:32 PM
 */

    //Purpose Prompt
    cout<<endl;
    cout<<"This program calculates an objects weight in Newtons."<<endl;
    cout<<endl;

    //Declare Variables
    float mass; //The object's mass
    float weight; //The object's weight
    
    //Input mass
    cout<<"Enter the object's mass in kilograms."<<endl;
    cin>>mass;
    cout<<endl;
    
    //Calculate weight in newtons
    weight=mass*9.8;
            
    //Validate data
    if(weight>1000){
        cout<<"The object is too heavy."<<endl;
        cout<<endl;
    }
    else if(weight<10){
        cout<<"The object is too light."<<endl;
        cout<<endl;
    }
    else{
        cout<<"The object weighs "<<weight<<" newtons."<<endl;
    }
    break;
            }
            case 7:{
/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program converts seconds to minutes, hours, or days, depending on the 
 * number of seconds inputted.
 * Created on March 26, 2016, 10:32 PM
 */

    //Purpose Prompt
    cout<<endl;
    cout<<"This program converts seconds to minutes, hours, or days,"<<endl;
    cout<<"depending on the number of seconds inputted."<<endl;
    cout<<endl;

    //Constants
    const float SIM(60); //The number of seconds in a minute
    const float SIH(3600); //The number of seconds in an hour
    const float SID(86400); //The number of seconds in a day
    
    //Declare variables
    float numSec; //Number of seconds inputted
    
    //Input number of seconds
    cout<<"Input number of seconds for conversion."<<endl;
    cin>>numSec;
    cout<<endl;
    
    //Convert to minutes, days, or hours.
    if(numSec<60&&numSec>=0){
        cout<<numSec<<" seconds is "<<numSec<<" seconds, did you really need to"
                " know that?"<<endl;
        cout<<endl;
    }
    
    else if(numSec<3600&&numSec>=60){
        cout<<numSec<<" seconds makes up "<<numSec/SIM<<" minutes."<<endl;
        cout<<endl;
    }
    
    else if(numSec>=3600&&numSec<86400){
        cout<<numSec<<" seconds makes up "<<numSec/SIH<<" hours."<<endl;
        cout<<endl;
    }
    
    else if(numSec>=86400){
        cout<<numSec<<" seconds makes up "<<numSec/SID<<" days."<<endl;
        cout<<endl;
    }
    
    else{
        cout<<"Error: Negative Value"<<endl;
        cout<<endl;
    }
    break;
            }
            case 8:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program determines the secondary color made by two given primary colors.
 * Created on March 26, 2016, 10:32 PM
 */

    //Purpose Prompt
    cout<<endl;
    cout<<"This program determines the secondary color made by two given "
            "primary colors."<<endl;
    cout<<endl;

    //Declare variables
    string color1; //First primary color
    string color2; //Second primary color
    
    //Input primary colors
    cout<<"Input the first primary color you'd like to mix."<<endl;
    cin>>color1;
    cout<<"Input the second primary color you'd like to mix."<<endl;
    cin>>color2;
    cout<<endl;
    
    //Determine secondary color and output results
    if(color1=="red"||color1=="Red"){
        
        if(color2=="yellow"||color2=="Yellow"){
            cout<<"The colors red and yellow make orange."<<endl;
            cout<<endl;
        }
        
        else if(color2=="blue"||color2=="Blue"){
            cout<<"The colors red and blue make purple."<<endl;
            cout<<endl;
        }
        
        else if(color2=="red"||color2=="Red"){
            cout<<"You entered red twice, so you end up with red."<<endl;
            cout<<endl;
        }
        
        else{
        cout<<"Error! You entered one or more non-primary colors."<<endl;
        cout<<endl;
        }
    }
    
    else if(color1=="yellow"||color1=="Yellow"){
        
        if(color2=="yellow"||color2=="Yellow"){
            cout<<"You entered yellow twice, so you end up with yellow."<<endl;
            cout<<endl;
        }
        
        else if(color2=="blue"||color2=="Blue"){
            cout<<"The colors yellow and blue make orange."<<endl;
            cout<<endl;
        }
        
        else if(color2=="red"||color2=="Red"){
            cout<<"The colors yellow and red make orange."<<endl;
            cout<<endl;
        }
        
        else{
        cout<<"Error! You entered one or more non-primary colors."<<endl;
        cout<<endl;
        }
    }
    
    if(color1=="blue"||color1=="Blue"){
        
        if(color2=="yellow"||color2=="Yellow"){
            cout<<"The colors blue and yellow make green."<<endl;
            cout<<endl;
        }
        
        else if(color2=="blue"||color2=="Blue"){
            cout<<"You entered blue twice, so you end up with blue."<<endl;
            cout<<endl;
        }
        
        else if(color2=="red"||color2=="Red"){
            cout<<"The colors blue and red make purple."<<endl;
            cout<<endl;
        }
        
        else{
        cout<<"Error! You entered one or more non-primary colors."<<endl;
        cout<<endl;
        }
    }
    
    else{
        cout<<"Error! You entered one or more non-primary colors."<<endl;
        cout<<endl;
    }}
    break;
    
            case 9:{
/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program tells the user to input the number of quarters, dimes, nickels,
 * and pennies in any combination to make up one dollar.
 * Created on March 26, 2016, 10:32 PM
 */

    //Purpose Prompt
    cout<<endl;
    cout<<"This program tells the user to input the number of quarters, dimes, "
            "nickels,"<<endl;
    cout<<"and pennies it takes in any combination to make up one dollar."
            <<endl;
    cout<<endl;
    
    //Constants
    float PID(100); //Pennies in a dollar
    float NID(20); //Nickels in a dollar
    float DID(10); //Dimes in a dollar
    float QID(4); //Quarters in a dollar

    //Declare variables
    int numPen; //Number of pennies inputted
    int numNick; //Number of nickels inputted
    int numDime; //Number of dimes inputted
    int numQuar; //Number of quarters inputted
    float totVal; //Total cash value of all coins inputted
    
    //Input number of coins
    cout<<"Input the number of pennies, nickels, dimes, and quarters (IN THAT "
            "ORDER, separated by spaces) you'd like to input."<<endl;
    cin>>numPen>>numNick>>numDime>>numQuar;
    cout<<endl;
    
    //Calculate total value of the coins
    totVal=(numPen/PID)+(numNick/NID)+(numDime/DID)+(numQuar/QID);
    
    //Determine victory or loss, and output results.
    if(totVal==1){
        cout<<"Congratulations, you win!"<<endl;
        cout<<endl;
    }
    
    else if(totVal<1){
        cout<<"You lost, your change came up short!"<<endl;
        cout<<endl;
    }
    
    else if(totVal>1){
        cout<<"You lost, too much change!"<<endl;
    }
    
    else{
        cout<<"Invalid input!"<<endl;
        cout<<endl;
    }}
    break;
    
            case 10:{
                /* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program determines the number of days in a given month during a given 
 * year.
 * Created on March 26, 2016, 10:32 PM
 */

    //Purpose Prompt
    cout<<endl;
    cout<<"This program determines the number of days in a given month during a"
            " given year"<<endl;
    cout<<endl;
    
    //Declare variables
    int month; //Inputted month
    int year; //Inputted year
    int numDays; //Number of days in the inputted month
    int lyi; //Leap Year Identifier (1 for true, 0 for false)
    
    //Input month and year
    cout<<"Input the month and year in numeric form, separated by a space"
            "(mm yyyy)."<<endl;
    cin>>month>>year;
    cout<<endl;
    
    //Determine if the year is a leap year
    if((year%100)==0){
        
        if((year%400)==0){
            lyi=1;
        }
        
        else{
            lyi=0;
        }
    }
    
    else if((year%100)>0){
        
        if((year%4)==0){
            lyi=1;
        }
    }    
        
    else cout<<"Invalid year!"<<endl;
    
    //Calculate number of days and output results
    if(month==1||month==3||month==5||month==7||month==8||month==10||month==12){
        
        cout<<"31 days"<<endl;
        cout<<endl;
    }
    
    else if(month==4||month==6||month==9||month==11){
        
        cout<<"30 days"<<endl;
        cout<<endl;
    }
    
    else if(month==2){
        
        if(lyi==1){
            
            cout<<"29 days"<<endl;
            cout<<endl;
        }
        
        else{
            
            cout<<"28 days"<<endl;
            cout<<endl;
        }
    }
    
    else{
        
        cout<<"Invalid month!"<<endl;
        cout<<endl;
    }
    break;
            }
            default:{
                    cout<<"Exit?"<<endl;
            }
    };
    }while(choice<=10&&choice>0);
    return 0;
}