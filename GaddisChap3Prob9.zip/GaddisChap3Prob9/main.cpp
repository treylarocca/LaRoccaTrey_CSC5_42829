/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates the number of widgets on a pallet based on weight.
 * Created on February 28, 2016, 6:28 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set data types for weight of widgets, number of widgets, weight of pallet
    //alone, and weight of pallet with widgets
    int nw;
    float wow, wpa, wpww;
    
    //Input weight data
    cout<<"How much does the pallet weigh, by itself, in pounds?"<<endl;
    cin>>wpa;
    cout<<"How much does the pallet weigh, in pounds, with all widgets on it"
            <<endl;
    cin>>wpww;
    
    //Calculate number of widgets
    wow=wpww-wpa;
    nw=wow/12.5;
    cout<<"There are "<<nw<<" widgets on the pallet."<<endl;
        
    return 0;
}

