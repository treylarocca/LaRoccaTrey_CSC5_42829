/* 
 * File:   main.cpp
 * Author: Trey LaRocca
 * This program calculates how many calories you have consumed by eating cookies
 * Created on February 28, 2016, 6:44 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {

    //Set data types for cookies eaten, and total calories consumed.
    int cookeat, totcal;
    
    //Input the number of cookies consumed
    cout<<"How many cookies did you eat? "
            "(I am sentient and will know if you lie)"<<endl;
    cin>>cookeat;
    
    //Calculate number of cookies eaten
    totcal=cookeat*100;
    cout<<"You consumed "<<totcal<<" calories by eating "<<cookeat<<" cookies."
            <<endl;
    cout<<"Are you proud of yourself?"<<endl;
    
    
                       
    return 0;
}

